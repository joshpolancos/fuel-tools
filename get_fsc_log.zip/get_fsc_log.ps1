﻿$psftp = "C:\Users\jpola12\Desktop\psftp.exe"
$dl = "C:\Users\jpola12\Downloads"
$user = "8373"
$pass = "2RU49685"
$file = "ftp.txt"
$store = $args[0]
$mlog = $args[1]
$cc = "cc$store"

if($mlog -eq "mlog"){
    "mlog"
    "cd f:/fsc/mlog" | Out-File $file -Force oem
    "get fscCC.0 $store-mlog-fscCC.0" | Out-File $file -Append oem
    "bye" | Out-File $file -Append oem

} else {
    "cd f:/fsc/log" | Out-File $file -Force oem
    "get fscCC.0 $store-fscCC.0" | Out-File $file -Append oem
    "bye" | Out-File $file -Append oem
}

"Connecting to $cc"
cmd /c "echo n | C:\Users\jpola12\Desktop\psftp.exe $cc -l $user -pw $pass -b $file"










