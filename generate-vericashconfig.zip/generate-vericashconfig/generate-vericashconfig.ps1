﻿param(
    [Parameter(Mandatory=$true)]
    [string]$storeNumber
)



$isp = "i$storeNumber"
$pingResult = @()
$pingTest = ping $isp
$divStore = $null
$vericashTemplate = "files/template"
$vericashConfig = "VericashConfig_en.properties"

"Generating $vericashConfig for store $storeNumber..."

if(Test-Connection $isp -ErrorAction SilentlyContinue -Quiet){
    ping "i$storeNumber" | ForEach-Object { $pingResult+=$_ }
    $divStore = ($pingResult[1]).substring(9,6)

}else {
        "Unable to connect to $isp"
}

(Get-Content $vericashTemplate).Replace('replace',$divStore) | Out-File "$storeNumber-$vericashConfig" -Force

"Done"
dir "$storeNumber*" | select Name

