import tlogrecovermodule
import configparser
import pandas as pd

config = configparser.ConfigParser()
config.read('..\list\config.ini')
azure_connection_string = config['Azure']['AzureConnectionString']
share_name = config['Azure']['SourceShare']
az_src_dir = config['Azure']['SourceDirectory2']
dest_share = config['Azure']['DestinationShare']
dest_dir = config['Azure']['DestinationDirectory']

txn_date = input("Date (MM-DD-YYYY): ")
julian_date = input("Julian Date: ")
tlog_list = input("Store List: ")

tlog_recover = []
# tlogs = []

c = 0

file = open(tlog_list,"r")
lines = file.readlines()

for l in lines:
    l = l.replace("\n","")
    tlog_recover.append(l)

for i in range(len(tlog_recover)):
    store_num = tlog_recover[i]
    source_directory = az_src_dir
    tlogfiles = tlogrecovermodule.listFiles(azure_connection_string,share_name,source_directory)

    for t in tlogfiles:
        if t.startswith(store_num) and julian_date in t:
            # print(t + ",nasa list: " + store_num + ", " + julian_date)

            src_url = "https://tlogbackupsa.file.core.windows.net/tlogbackup/" + az_src_dir + "/" + t
            renamed_file = tlogrecovermodule.generateNewFilename(t,tlog_recover,txn_date,c)
            # tlogs.append(t)

            # print(renamed_file)

            print("Copying " + src_url + " to " + dest_share + " > " + dest_dir + " as " + renamed_file)
            
            tlogrecovermodule.copyFile(azure_connection_string, dest_share, dest_dir, renamed_file, src_url)
        # else:
        #     print(t + " does not contain " + julian_date)

    c+=1

# for tl in tlogs:
#     print(tl)
