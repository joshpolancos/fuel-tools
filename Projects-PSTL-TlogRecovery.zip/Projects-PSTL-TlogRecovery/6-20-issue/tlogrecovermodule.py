import pandas
import os
import shutil
import random
from random import randint, randrange
from azure.storage.file.fileservice import FileService
from azure.storage.fileshare import ShareFileClient
from datetime import datetime, timedelta
from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError
)

def listFiles(connstring, azureshare, azuredirectory):
    srctloglist = []
    file_service = FileService(connection_string=connstring)
    files_in_dir = file_service.list_directories_and_files(azureshare, directory_name=azuredirectory)
    for file_or_dir in files_in_dir:
        srctloglist.append(file_or_dir.name)
    return srctloglist

def generateNewFilename(tlogfile,date_range_coll,txn_date,idx):
    
    file_date = txn_date.replace("-","")
    len_tlog = len(date_range_coll)
    bn = random.sample(range(1000, 9999), len_tlog)
    tm = random.randint(1000, 2300)
    store_num = tlogfile[0:4]
    new_storenum = "0" + store_num


    batch_num = str(bn[idx])
    file_time = str(tm)

    ac_filename = "AC_" + file_date + file_time + "_" + new_storenum + "_" + batch_num + ".DAT"
    
    return ac_filename


def copyFile(constring, destshare, destdir, destfile, srcurl):
    filemetadata = {'RIO_READY': 'true'}
    file_service = FileService(connection_string=constring)
    file_service.copy_file(destshare, destdir, destfile, srcurl, metadata=filemetadata)
