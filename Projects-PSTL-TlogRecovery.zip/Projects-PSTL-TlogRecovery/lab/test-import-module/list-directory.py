import mymodule

fileshare_name = input("Fileshare: ")
source_directory = input("Directory/Path: ")

azure_connection_string = "DefaultEndpointsProtocol=https;AccountName=tlogbackupsa;AccountKey=HjYdtW7v6bqvAYftamDOW71P2Hs3mEmUiscHHu4Bf6U6WbZVts/naiaTFCz312SnSmaS9/EtIYh7xc1bAMX/LA==;EndpointSuffix=core.windows.net"

contents = []

def listFiles(con_string, share_name, dir):

    file_service_contents = []

    file_service = fs.FileService(connection_string=con_string)
    files_in_dir = file_service.list_directories_and_files(share_name, directory_name=dir)

    for f in files_in_dir:
        file_service_contents.append(f)
    
    for fc in file_service_contents:
        contents.append(fc)

listFiles(azure_connection_string, fileshare_name, source_directory)

for c in contents:
        print(c)