import pandas
import os
import shutil
import random
import configparser
from random import randint, randrange
from azure.storage.file.fileservice import FileService as fs
from azure.storage.fileshare import ShareFileClient
from datetime import datetime, timedelta
from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError
)





    

