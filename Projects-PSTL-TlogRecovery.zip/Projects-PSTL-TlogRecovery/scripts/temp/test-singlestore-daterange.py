import tlogrecovermodule
import configparser
import random

config = configparser.ConfigParser()
config.read('..\list\config.ini')
azure_connection_string = config['Azure']['AzureConnectionString']
share_name = config['Azure']['SourceShare']
az_src_dir = config['Azure']['SourceDirectory']


# files = tlogrecovermodule.listFiles(azure_connection_string,share_name,az_src_dir)

# for f in files:
#     if f.startswith("1234"):
#         print(f)

# batch_num = random.sample(range(1000, 9999), 2500)

# print(batch_num)

boom = ["1","2"]

def generateNewFilename(sn,coll):
    # file_date = txn_date.replace("-","")
    file_date = "05212023"
    len_coll = len(coll)
    bn = random.sample(range(1000, 9999), len_coll)
    # bn = random.randint(1000, 9999)
    tm = random.randint(1000, 2300)
    store_num = sn[0:4]
    new_storenum = "0" + store_num

    batch_num = str(bn)
    file_time = str(tm)

    ac_filename = "AC_" + file_date + file_time + "_" + new_storenum + "_" + batch_num + ".DAT"
    # ac_filename = "AC_" + file_date + file_time + "_" + new_storenum
    return ac_filename

for i in range(len(boom)):
    print(generateNewFilename("123423T.141",boom))
    