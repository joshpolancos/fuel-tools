import pandas
from azure.storage.file.fileservice import FileService
from azure.storage.fileshare import ShareFileClient
import os
import shutil
from datetime import datetime, timedelta
from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError
)

def getStoreNumbersFromAzureDir(constring, srcshare, srcdir):
    file_service = FileService(connection_string=constring)
    files_in_dir = file_service.list_directories_and_files(srcshare, directory_name=srcdir)
    srctloglist = []
    storenumberfromazuredir = []
    for file_or_dir in files_in_dir:
        srctloglist.append(file_or_dir.name)
    ####################Find missing batch ids for stores
    # get list of store numbers from batch id excel file and store list from azure dir
    for x in srctloglist:
        storenumberfromazuredir.append('0' + x[0:4])

    #for item in batchids:
     #   storelistfrombatchidfile.append(item['Store'])


print(getStoreNumbersFromAzureDir)