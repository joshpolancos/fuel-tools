start_month = date_start[0:3]
    end_month = date_end[0:3]
    start_year = date_start[5:10]
    end_year = date_end[5:10]
    start_dt = date_start[3:5]
    end_dt = date_end[3:5]
    start_date = int(start_dt)
    end_date = int(end_dt)

    for txn_dt in range(start_date,end_date + 1):
        txn_dates = 
        transaction_dates.append(txn_dates)


list = "./list/stores.txt"
stores = []

def getStoreList():
    with open(list) as store_list:
        str_num = store_list.read().splitlines()

        for st in str_num:
            stores.append(st)

    store_list.close()

#getStoreList()