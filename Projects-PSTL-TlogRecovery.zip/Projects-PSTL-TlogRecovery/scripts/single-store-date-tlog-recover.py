import pandas
import os
import shutil
import random
import configparser
from random import randint, randrange
from azure.storage.file.fileservice import FileService
from azure.storage.fileshare import ShareFileClient
from datetime import datetime, timedelta
from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError
)

store_num = input("Store Number: ")
txn_date = input("Tlog Folder Date (MM-DD-YYYY): ")

config = configparser.ConfigParser()
config.read('list\config.ini')
azure_connection_string = config['Azure']['AzureConnectionString']
share_name = config['Azure']['SourceShare']
#azure_connection_string = "DefaultEndpointsProtocol=https;AccountName=tlogbackupsa;AccountKey=HjYdtW7v6bqvAYftamDOW71P2Hs3mEmUiscHHu4Bf6U6WbZVts/naiaTFCz312SnSmaS9/EtIYh7xc1bAMX/LA==;EndpointSuffix=core.windows.net"
#share_name = "tlogbackup"
source_directory = "tlogbackupfolders/" + txn_date
dest_share = config['Azure']['DestinationShare']
dest_dir = config['Azure']['DestinationDirectory']
source_url = "https://tlogbackupsa.file.core.windows.net/tlogbackup"
cp_src_url = source_url + "/tlogbackupfolders/" + txn_date + "/"

tlog_recover = []


def getStoreNumbersFromAzureDir(constring, srcshare, srcdir):
    file_service = FileService(connection_string=constring)
    files_in_dir = file_service.list_directories_and_files(srcshare, directory_name=srcdir)
 
    srctloglist = []
    storenumberfromazuredir = []
    #tlogdir = []

    for file_or_dir in files_in_dir:
        srctloglist.append(file_or_dir.name)
 
    for tlog_file in srctloglist:
        if tlog_file.startswith(store_num):
            tlog_recover.append(tlog_file)
            print(tlog_file)
     
    

def copyFile(constring, destshare, destdir, destfile, srcurl):
    filemetadata = {'RIO_READY': 'true'}
    file_service = FileService(connection_string=constring)
    file_service.copy_file(destshare, destdir, destfile, srcurl, metadata=filemetadata)

def listDestinationDir(constring, srcshare, srcdir):
    file_service = FileService(connection_string=constring)
    files_in_dir = file_service.list_directories_and_files(srcshare, directory_name=srcdir)

    srctloglist = []

    for file_or_dir in files_in_dir:
        srctloglist.append(file_or_dir.name)

    for tlog_file in srctloglist:
        print(tlog_file)


def generateNewFilename():
    file_date = txn_date.replace("-","")
    bn = random.randint(1000, 9999)
    tm = random.randint(1000, 2300)
    new_storenum = "0" + store_num

    batch_num = str(bn)
    file_time = str(tm)

    ac_filename = "AC_" + file_date + file_time + "_" + new_storenum + "_" + batch_num + ".DAT"

    return ac_filename

#print(generateNewFilename())


#-----------------------------------
# Main
#-----------------------------------
getStoreNumbersFromAzureDir(azure_connection_string,share_name,source_directory)


print("")
for tlog_file in tlog_recover:
    src_url =  cp_src_url + tlog_file
    renamed_file = generateNewFilename()
    
    copyFile(azure_connection_string, dest_share, dest_dir, renamed_file, src_url)
    
    print("Copying " + tlog_file + " as " + renamed_file + " to " + dest_dir)

print("")
print("Listing " + dest_dir)

listDestinationDir(azure_connection_string,dest_share,dest_dir)
