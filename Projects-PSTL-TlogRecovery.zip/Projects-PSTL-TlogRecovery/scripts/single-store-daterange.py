import tlogrecovermodule
import configparser
import pandas as pd

config = configparser.ConfigParser()
config.read('list\config.ini')
azure_connection_string = config['Azure']['AzureConnectionString']
share_name = config['Azure']['SourceShare']
az_src_dir = config['Azure']['SourceDirectory']
dest_share = config['Azure']['DestinationShare']
dest_dir = config['Azure']['DestinationDirectory']

store_num = input("Store: ")
print("Date Format - MM-DD-YYYY")
date_start = input("Date Start: ")
date_end = input("Date End: ")

transaction_dates = []
# tlog_recover = []
tlog_files = []

c = 0

def processDateRange():
    
    txn_dates = pd.date_range(start = date_start, end = date_end)

    for dt in txn_dates:
        txn_month = dt.strftime('%m')
        txn_dt = dt.strftime('%d')
        txn_year = dt.strftime('%Y')

        new_txn_dates = txn_month + '-' + txn_dt + '-' + txn_year

        transaction_dates.append(new_txn_dates)

processDateRange()

# ------------------------------------------------

for i in range(len(transaction_dates)):
    txndate = transaction_dates[i]
    source_directory = az_src_dir + "/" + txndate

    date_range_files = tlogrecovermodule.listFiles(azure_connection_string,share_name,source_directory)

    for f in date_range_files:
        if f.startswith(store_num):
            #test url
            src_url = "https://tlogbackupsa.file.core.windows.net/tlogbackup/" + az_src_dir + "/" + txndate + "/" + f
            tlog_files.append(f)
            renamed_file = tlogrecovermodule.generateNewFilename(f,tlog_files,txndate,c)
            print("Copying " + src_url + " to " + dest_share + " > " + dest_dir + " as " + renamed_file)
            tlogrecovermodule.copyFile(azure_connection_string, dest_share, dest_dir, renamed_file, src_url)

            c+=1
