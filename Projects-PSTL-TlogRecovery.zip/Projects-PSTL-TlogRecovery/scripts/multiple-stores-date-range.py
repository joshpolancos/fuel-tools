import tlogrecovermodule
import configparser
import pandas as pd

config = configparser.ConfigParser()
config.read('list\config.ini')
azure_connection_string = config['Azure']['AzureConnectionString']
share_name = config['Azure']['SourceShare']
az_src_dir = config['Azure']['SourceDirectory']
# dest_share = config['Azure']['DestinationShare']
dest_dir = config['Azure']['DestinationDirectory2']

tlog_list = input("Store List: ")
date_start = input("Date Start: ")
date_end = input("Date End: ")

tlog_recover = []
transaction_dates = []

test_tlog = []

c = 0

def processDateRange():
    
    txn_dates = pd.date_range(start = date_start, end = date_end)

    for dt in txn_dates:
        txn_month = dt.strftime('%m')
        txn_dt = dt.strftime('%d')
        txn_year = dt.strftime('%Y')

        new_txn_dates = txn_month + '-' + txn_dt + '-' + txn_year

        transaction_dates.append(new_txn_dates)

processDateRange()

file = open(tlog_list,"r")
lines = file.readlines()

for l in lines:
    l = l.replace("\n","")
    tlog_recover.append(l)

for dates in transaction_dates:
    txn_date = str(dates)
    source_directory = az_src_dir + "/" + txn_date

    tlogs_with_date_d = tlogrecovermodule.listFiles(azure_connection_string,share_name,source_directory)


    for t in tlogs_with_date_d:
        for stores in tlog_recover:
            if t.startswith(stores):
                src_url = "https://tlogbackupsa.file.core.windows.net/tlogbackup/" + az_src_dir + "/" + txn_date + "/" + t
                renamed_file = tlogrecovermodule.generateNewFilename(t,tlog_recover,txn_date,c)

                print("Copying " + src_url + " to " + share_name + " > " + dest_dir + " as " + renamed_file)
                
                tlogrecovermodule.copyFile(azure_connection_string, share_name, dest_dir, renamed_file, src_url)
