file = open("batch2.txt","r")
lines = file.readlines()

for l in lines:
    l = l.replace("\n","")
    print(l)