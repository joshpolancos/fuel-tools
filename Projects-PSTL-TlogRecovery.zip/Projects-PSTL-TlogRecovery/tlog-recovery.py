import os

msg = """
Tlog Recovery Tool
----------------------
Modes:
1.) Single Store - Specific Date
2.) Single Store - Date Range
3.) Multiple Stores - Specific Date
4.) Multiple Stores - Date Range
5.) Reprocess from tlogbackupfiles
"""

def selectMode():
    mode = input("Select Mode: ")
    
    return mode



print(msg)
mode_selected = selectMode()

match mode_selected:
    case "1":
        print("Selected Single Store - Specific Date \n")
        os.system("python ./scripts/single-store-date-tlog-recover.py")
    case "2":
        print("Selected Single Store - Date Range \n")
        os.system("python ./scripts/single-store-daterange.py")
    case "3":
        print("Selected Multiple Stores - Specific Date")
        os.system("python ./scripts/multiple-stores-specific-date.py")
    case "4":
        print("Selected Multiple Stores- Date Range")
        os.system("python ./scripts/multiple-stores-date-range.py")
    case "5":
        print("Selected reprocess from tlogbackupfiles - Specific Date")     
        os.system("python ./scripts/recover-from-tlogbackupfiles.py")                   
    case _:
        print("Invalid mode")