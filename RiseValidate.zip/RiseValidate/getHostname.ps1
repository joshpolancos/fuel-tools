﻿#$sn = read-host "Store Number"
$sn = $args[0]

function getHostname($s){

    $hash = @{ 
        "05" = "DEN"
        "17" = "PHX"
        "19" = "POR"
        "20" = "HOU"
	"24" = "HGN"
        "25" = "NCA"
        "27" = "SEA"
        "29" = "SCA"
        "30" = "INT"
        "32" = "JWL"
        "33" = "SHW"
        "34" = "ACM"
        "35" = "WDC"
    }
    

    $StoreNumber = $s
    $sn = "{0:d4}" -f $StoreNumber

    $PingTest = ping -n 1 "i$sn"

    #Get Div number
    $Div = $null
    $Div = $PingTest -match "i[0-9][0-9][0-9][0-9]"
    $Div = $Div.substring(9,2)
        
    $divCode = $hash.get_item($Div)

    $result = "$divCode" + $sn + "L1"

    return $result

}

getHostname $sn
