﻿param([string]$st)

#cls
$stores

if ($st -contains ','){
    $stores = $st | foreach-object { $_.split(",") }
    

} else {
    $stores = $st.split()
}

$result=$null


foreach($s in $stores){
$s = $s.padLeft(4,'0')
#$s
$url = 'http://operations.safeway.com/sinfo/index.cgi?store=' + $s + '&misc='
$restResponse = Invoke-RestMethod $url
$hasFuel = $restResponse | ForEach-Object { $_ -match 'fuel' }

    $fuel = \tools\getHostname.ps1 $s
    $vb = $fuel -replace "L1","E1"


    if ($hasFuel){
        if(Test-Connection $fuel -ErrorAction SilentlyContinue){
            $response = "$s, $fuel - good"
        }
    } else {
        $response = "$s, No Fuel"
    }

  
    if(Test-Connection $vb -ErrorAction SilentlyContinue){
        $response += ", $vb - good"
    } else {
        $response += ", $vb - down"
    }

    $response
}

<#
$stores= "2791,1548,1519,1491,1201"

$stores = $stores.Split(",")

$stores | ForEach-Object { $a = \tools\gethostname.ps1 $_ ; $vb = $a -replace "L1","E1" ; Test-Connection $a; Test-Connection $vb }#>