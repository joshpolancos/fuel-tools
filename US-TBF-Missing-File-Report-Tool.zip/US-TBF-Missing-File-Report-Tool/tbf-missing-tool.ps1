﻿cls
$host.ui.RawUI.WindowTitle = "Missing TBF Tool"
$list = (get-content .\list\list.txt).Trim()
$totalLines = ($list| Measure-Object -Line).Lines
$tbfStores = @()

"TBF Missing Tool"
"*****************************************"

function parseTbfFile($record){
    $len = $record.length
    $script:st = $null
    $script:month_date = $null

    if($len -gt 21){
        $st = ($record.substring($len-19,5)).trim()
        $month_date = (($record.substring($len-10,5)).trim()) -replace "-",""
    } else{
        $st = ($record.substring($len-16,6)).trim()
        $month_date = (($record.substring($len-10,5)).trim()) -replace "-",""
    }

    $storeNum = $st.PadLeft(4,'0')
    $tbfFile = "TBF$storeNum$month_date.txt"

    return $tbfFile
 
}


for ($i = 3; $i -le $totalLines; $i++){
    $tbfRecord = $list[$i]
    $tbfFiles = parseTbfFile($tbfRecord)
    $storeNum = $tbfFiles.substring(3,4)
    $tbfStores+=$storeNum
    #$machineName = .\getHostname.ps1 $storeNum
  
}

$filteredStores = $tbfStores | Get-Unique

.\files\tbfcheck.ps1 $filteredStores

#parseTbfFile("25    224    01-16-2023")


