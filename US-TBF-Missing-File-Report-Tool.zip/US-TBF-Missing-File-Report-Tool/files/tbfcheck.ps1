﻿param($stores)

"Running"

foreach ($s in $stores){
    $m = .\files\getHostname.ps1 $s

    
    Invoke-Command -ComputerName $m -ScriptBlock {
        #$tbfCount = dir \c-storecommander\Data\tbf1\tbf* | Measure-Object | ForEach-Object { $_.count } -ErrorAction SilentlyContinue
        $tbfCount = dir \c-storecommander\Data\tbf1\tbf* -ErrorAction SilentlyContinue | select -ExpandProperty Name 
        #| Write-Host -NoNewline
        $mimLog2 = Get-Content "\Program Files (x86)\Metastorm\MIM\logs\comp.log" | select -Last 10 | Out-File \temp\jcp.txt -Force -Encoding oem
        $mimLog = Get-Content \temp\jcp.txt -Raw
        $hn = hostname
        #$mimService = Get-Service -Name "Metastorm Integration Manager" | select Status,Name
        $mimService = Get-Service -Name "Metastorm Integration Manager" | select -ExpandProperty Status
        
        $mimResult = New-Object PSObject

        Add-Member -InputObject $mimResult -MemberType NoteProperty -Name MachineName -Value $hn
        Add-Member -InputObject $mimResult -MemberType NoteProperty -Name Tbf1 -Value $tbfCount
        Add-Member -InputObject $mimResult -MemberType NoteProperty -Name MIMLog -Value $mimLog
        Add-Member -InputObject $mimResult -MemberType NoteProperty -Name MIMService -Value $mimService

        
        $mimResult | select MachineName,Tbf1,MIMService,MIMLog | Format-Table -Wrap

       
        
    }
    
}

$host.ui.RawUI.WindowTitle = "Done - Missing TBF Tool"