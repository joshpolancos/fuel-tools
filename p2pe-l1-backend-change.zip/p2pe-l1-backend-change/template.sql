DECLARE @count INT = 1;
DECLARE @portnum INT = 4000;
WHILE @count <= xpumpcount /*pumpCount*/
BEGIN

  update [UniversalReader].[dbo].[IP]
  set PortNumber = @portnum
  where ID = @count

  set @count = @count + 1
  set @portnum = @portnum + 1
 
END;
