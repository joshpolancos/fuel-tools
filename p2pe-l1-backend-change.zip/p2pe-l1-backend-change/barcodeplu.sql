		USE CSCADMIN
		DECLARE @P_SEQ INT
		IF NOT EXISTS (SELECT * FROM [P_COMP] WHERE P_NAME = 'BarCodePLU')
		BEGIN
		       SET @P_SEQ = (SELECT MAX(P_SEQ) FROM [P_COMP]) + 10
		       SELECT @P_SEQ
		       INSERT INTO [CSCAdmin].[dbo].[P_COMP]
		           ([P_CLASS],[P_SEQ],[Implemented],[P_NAME],[P_DESC],[P_LEVELS],[P_CHOICES],[P_SET],[P_VARTYPE],[P_ACTIVE],[P_USED])
		                     VALUES ('FUELSF',@P_SEQ,1,'BarCodePLU','BarCode PLU Number','{COMPANY}','{?}','  ','C',1,1)
		END
		
		UPDATE [CSCAdmin].[dbo].[P_COMP] SET P_Set = '  ' WHERE P_NAME ='BarCodePLU'
