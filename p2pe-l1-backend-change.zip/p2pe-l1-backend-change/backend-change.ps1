﻿$machine = Read-Host "L1 Machine"

function testConnect($m){
    $result = $null

    if(Test-Connection $m -Quiet){
        $result = "true"
    }else {
        $result = "false"
    }

    return $result
}

function getPumpCount($m){
    

    $pumpCount = Invoke-Command -ComputerName $m -ScriptBlock{
        
        $count = $null

        $fcsLogPath = "\nextgenfuel\fcsservice\logs"
        $fcsLog = "fcs.log"
        
        Push-Location $fcsLogPath
        $statEventResult = @()
        $statEvent = $null
        $statEvent = Select-String "status event" $fcsLog | select -Last 1 | Out-String
        #$statEvent
        $statEvent = $statEvent -split ":"
        
        $statEventResult+=$statEvent
        $pumpCount = (($statEventResult[6]).Trim()).Length

        $count = $pumpCount

        return $count
        
        Pop-Location
        
    }

    return $pumpCount

}

function updatePortQuery($c){
    $template = "template.sql"
    $old = "xpumpcount"
    
    (Get-Content $template) -replace "$old","$c" | Out-File "updatePortQuery.sql" -Force
}


function runUpdatePortQuery($m){
    $queryFile = "updatePortQuery.sql"
    copy $queryFile "\\$m\c$\temp" -ErrorAction Stop

    Invoke-Command -ComputerName $m -ScriptBlock {
        cd \temp
        if(Test-Path "updatePortQuery.sql"){
            SQLCMD.EXE -S localhost\SQLEXPRESS -i updatePortQuery.sql -o updatePortQuery.log -h -1 -s ","
            Get-Content updatePortQuery.log
        }else{
            "updatePort query file does not exist"
        }
    }
}

function runUpdateDeviceTypeQuery($m){
    

    Invoke-Command -ComputerName $m -ScriptBlock {
        cd "\NextGenFuel\BackOffice\Scripts\Ixpay Secure Connect Script"
        SQLCMD.EXE -S localhost\SQLEXPRESS -i UniversalReader.DeviceType.SQL -o \temp\UniversalReaderDeviceType.SQL.log -h -1 -s ","
            Get-Content \temp\updatePortQuery.log
        
    }
}

function runBarCodePluQuery($m){
    $queryFile = "barcodeplu.sql"
    copy $queryFile "\\$m\c$\temp" -ErrorAction Stop

    Invoke-Command -ComputerName $m -ScriptBlock {
        cd \temp
        if(Test-Path "barcodeplu.sql"){
            SQLCMD.EXE -S localhost\SQLEXPRESS -i barcodeplu.sql -o barcodeplu.log -h -1 -s ","
            Get-Content updatePortQuery.log
        }else{
            "barcodeplu query file does not exist"
        }
    }
}

function restartFuelService($m){

    Invoke-Command -ComputerName $m -ScriptBlock{
        Stop-Service "OPTService" -WarningAction Ignore -PassThru
        Stop-Service "FCSService" -WarningAction Ignore -PassThru
        "Waiting for 1 min."
        Start-Sleep -Seconds 60
        Start-Service "OPTService" -WarningAction Ignore -PassThru
        Start-Service "FCSService" -WarningAction Ignore -PassThru
    }
}

#------------------------------------------------------------

"Testing connection to $machine"
$connectionStatus = testConnect $machine

if($connectionStatus -eq 'true'){
    "Good"
    
    "Determining pump count for $machine"

    $pumpCount = getPumpCount $machine
    
    $pumpCount

    "Generating update port query file"
    updatePortQuery $pumpCount

    #Get-Content "updatePortQuery.sql"

    "Run update port query"
    runUpdatePortQuery $machine

    "Run UniversalReader.DeviceType.SQL"
    runUpdateDeviceTypeQuery $machine

    "Run BarCodePlu query"
    runBarCodePluQuery $machine

    "Restart FCS and OPT Service"
    restartFuelService $machine


}else{
    "Failed. Unable to connect to $machine"
}
