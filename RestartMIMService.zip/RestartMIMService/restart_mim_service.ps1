﻿"Restart MIM Service"
"------------------------------"

$list = "list.txt"

foreach ($m in Get-Content $list){
    
    $m

    Invoke-Command -ComputerName $m -ScriptBlock{
        $svc = "Metastorm Integration Manager"
        Restart-Service -Name $svc -PassThru -WarningAction SilentlyContinue
    }
    
    
}